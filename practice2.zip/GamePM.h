//Daniel Martín & Laura San Martín
#pragma once
#include <iostream>
#include "UtilitiesSYS.h"
#include "PuzzlesList.h"
#include <string>

using namespace std;

const int numOpt = 3;
int menu(); // To choose the mode or to insert a new puzzle
int mainGatheredPuzzles(); // Main program


