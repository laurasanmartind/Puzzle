#include <iostream>
#include <string>
#include "UtilitiesSYS.h"
#include "GamePM.h"
using namespace std;


int main() // Main function
{
	mainGatheredPuzzles();

	return 0;
}